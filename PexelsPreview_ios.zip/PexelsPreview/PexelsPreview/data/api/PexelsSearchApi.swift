//
//  PexelsSearchApi.swift
//  PexelsPreview
//
//  Created by tatsuki on 2024/02/27.
//

import Foundation

class PexelsSearchApi {
    
}
