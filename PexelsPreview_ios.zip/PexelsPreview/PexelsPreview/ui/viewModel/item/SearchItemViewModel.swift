//
//  SearchItemViewModel.swift
//  PexelsPreview
//
//  Created by tatsuki on 2024/02/28.
//

import Foundation

struct SearchItemViewModel {
    let small: URL
    let medium: URL
    let photographer: String
}
